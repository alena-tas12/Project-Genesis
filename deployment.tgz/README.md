# Project Genesis - MoSPI SIH 26101 Platform

An educational-systems research simulator with a local, secure-by-default prototype for MoSPI capacity building: competency gaps, tailored learning pathways, document extraction, reviewable assessment drafts, and an iGOT integration boundary.

## Run locally

1. Run `npm install`.
2. Copy `.env.example` to `.env` and replace `JWT_SECRET` with a long random value.
3. Start the API in one terminal: `npm run server`.
4. Start the web app in another: `npm run dev`.

For local development, run it with `PORT=8787`; for the server deployment use `PORT=82`. The single server then provides both the website and API. On first start, it creates a local SQLite database under `data/` and a bootstrap administrator for local testing:

- Email: `admin@local.mospi`
- Password: `ChangeMe!26101`

Change this account and password before sharing or deploying the system.

## What is implemented

- React/Vite research and SIH dashboard
- Document text extraction: TXT/MD/CSV/JSON, PDF, and DOCX
- SQLite persistence for source documents and assessments
- JWT authentication and admin/reviewer role checks
- Audit events for login, upload, generation, review, and approval
- Review gate: generated assessments are drafts until a reviewer approves them
- iGOT integration-readiness endpoint with no misleading live-sync claim

## Important deployment boundary

This project is not connected to iGOT or MoSPI. A live integration needs an authorised sandbox, OAuth/SSO details, client credentials, a data-sharing agreement, retention policy, penetration test, and approval from those organisations. Do not upload real personnel data outside an approved environment.

## API

- `POST /api/auth/login`
- `POST /api/documents` (admin/reviewer, multipart `file`)
- `POST /api/assessments` (admin/reviewer; `text`, optional `documentId`)
- `GET /api/assessments` (authenticated)
- `PATCH /api/assessments/:id/review` (admin/reviewer; `draft` or `approved`)
- `GET /api/audit-events` (admin)
- `GET /api/integration-readiness` (authenticated)

Protected routes use `Authorization: Bearer <token>`.
