import React, { useState, type ChangeEvent } from 'react';
import { MoSPICompetencyFramework, type MoSPIOfficialProfile, type AdvancedGeneratedMCQ } from '../../engine/sih/mospiCompetencyFramework';
import { Award, Brain, CheckCircle, Database, FileText, Globe, Layers, LockKeyhole, RefreshCw, Server, ShieldCheck, Sparkles, Upload, Users, Zap } from 'lucide-react';

interface StoredAssessment { id: number; status: 'draft' | 'approved'; questions: AdvancedGeneratedMCQ[]; created_at: string; }

export const SIHMasterDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'heatmap' | 'profile' | 'nlp_quiz' | 'igot_api' | 'admin'>('heatmap');
  
  // Data State
  const cadres = MoSPICompetencyFramework.getCadresList();
  const officials = MoSPICompetencyFramework.getSampleMoSPIOfficials();

  const [selectedOfficial, setSelectedOfficial] = useState<MoSPIOfficialProfile>(officials[0]);
  const [selectedCadreFilter, setSelectedCadreFilter] = useState<string>('ALL');

  // NLP Quiz Generator State
  const [inputText, setInputText] = useState<string>(
    'MoSPI DIID Capacity Building Guidelines 2026:\nField officers in FOD and SDRD are required to adopt Computer-Assisted Personal Interviewing (CAPI) handheld tablets equipped with automated isolation forest algorithms to detect timestamp anomalies, non-response bias in urban strata, and GVA calculation errors.'
  );
  const [generatedQuizzes, setGeneratedQuizzes] = useState<AdvancedGeneratedMCQ[]>(() =>
    MoSPICompetencyFramework.parseDocumentAndGenerateNLPQuizzes(inputText, 4)
  );
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [showQuizResults, setShowQuizResults] = useState<boolean>(false);
  const [loadedFileName, setLoadedFileName] = useState<string>('');
  const [inputStatus, setInputStatus] = useState<string>('Paste material or load a text-based file. Content remains in this browser session.');
  const [integrationStatus, setIntegrationStatus] = useState<string>('Demo mode - no external iGOT request is sent.');
  const [adminEmail, setAdminEmail] = useState('admin@local.mospi');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminToken, setAdminToken] = useState(() => localStorage.getItem('mospi-admin-token') || '');
  const [adminStatus, setAdminStatus] = useState('Sign in to manage documents and assessment drafts.');
  const [adminFile, setAdminFile] = useState<File | null>(null);
  const [adminText, setAdminText] = useState('');
  const [storedAssessments, setStoredAssessments] = useState<StoredAssessment[]>([]);
  const filteredOfficials = selectedCadreFilter === 'ALL'
    ? officials
    : officials.filter(official => official.cadre === selectedCadreFilter);
  const recommendedCourses = MoSPICompetencyFramework.getRecommendedCoursesForOfficial(selectedOfficial);

  const handleGenerateNLPQuizzes = () => {
    if (inputText.trim().length < 20) {
      setInputStatus('Add at least a short paragraph of learning material before generating questions.');
      return;
    }
    const newQuizzes = MoSPICompetencyFramework.parseDocumentAndGenerateNLPQuizzes(inputText, 4);
    setGeneratedQuizzes(newQuizzes);
    setSelectedAnswers({});
    setShowQuizResults(false);
    setInputStatus(`Generated ${newQuizzes.length} questions from concepts detected in your submitted material.`);
  };

  const handleFileInput = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const supportedTypes = ['text/plain', 'text/markdown', 'text/csv', 'application/json'];
    const supportedExtension = /\.(txt|md|csv|json)$/i.test(file.name);
    if (!supportedTypes.includes(file.type) && !supportedExtension) {
      setLoadedFileName('');
      setInputStatus('This local MVP currently reads TXT, MD, CSV, and JSON. PDF/DOCX extraction needs a server-side document-processing service.');
      event.target.value = '';
      return;
    }

    const fileText = await file.text();
    setInputText(fileText);
    setLoadedFileName(file.name);
    setInputStatus(`Loaded ${file.name} locally. Review or edit the extracted text, then generate questions.`);
  };

  const handleSelectOption = (quizId: string, optionIdx: number) => {
    setSelectedAnswers(prev => ({ ...prev, [quizId]: optionIdx }));
  };

  const handlePrepareIntegration = () => {
    setIntegrationStatus('Integration checklist prepared locally. Live sync is disabled until MoSPI/iGOT supplies approved API credentials and a sandbox.');
  };

  const apiRequest = async (path: string, options: RequestInit = {}) => {
    const apiBase = import.meta.env.DEV ? 'http://localhost:8787' : window.location.origin;
    const response = await fetch(`${apiBase}${path}`, { ...options, headers: { ...(options.headers || {}), ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {}) } });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'The local service could not complete this request.');
    return data;
  };

  const handleAdminLogin = async () => {
    try {
      setAdminStatus('Signing in to the local administrator workspace...');
      const data = await apiRequest('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: adminEmail, password: adminPassword }) });
      localStorage.setItem('mospi-admin-token', data.token);
      setAdminToken(data.token);
      setAdminStatus(`Signed in as ${data.user.email}. Upload a learning document or paste material below.`);
    } catch (error) { setAdminStatus(error instanceof Error ? error.message : 'Sign-in failed.'); }
  };

  const loadAssessments = async () => {
    try { const data = await apiRequest('/api/assessments'); setStoredAssessments(data); } catch (error) { setAdminStatus(error instanceof Error ? error.message : 'Could not load assessments.'); }
  };

  const handleAdminUpload = async () => {
    if (!adminFile) return setAdminStatus('Choose a document first.');
    try {
      setAdminStatus('Extracting text securely in the local service...');
      const form = new FormData(); form.append('file', adminFile);
      const data = await apiRequest('/api/documents', { method: 'POST', body: form });
      setAdminText(data.text); setAdminStatus(`Extracted ${data.filename}. Review the text, then generate a draft assessment.`);
    } catch (error) { setAdminStatus(error instanceof Error ? error.message : 'Upload failed.'); }
  };

  const handleAdminGenerate = async () => {
    try {
      setAdminStatus('Creating a reviewable assessment draft...');
      const data = await apiRequest('/api/assessments', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: adminText }) });
      setAdminStatus(`Draft #${data.id} created. Review and approve it below.`); await loadAssessments();
    } catch (error) { setAdminStatus(error instanceof Error ? error.message : 'Generation failed.'); }
  };

  const handleReview = async (id: number, status: 'draft' | 'approved') => {
    try { await apiRequest(`/api/assessments/${id}/review`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) }); await loadAssessments(); setAdminStatus(`Assessment #${id} is now ${status}.`); } catch (error) { setAdminStatus(error instanceof Error ? error.message : 'Update failed.'); }
  };

  return (
    <div className="sih-master-container fade-in">
      {/* Enterprise Header Banner */}
      <div className="sih-master-banner">
        <div className="sih-header-top">
          <div className="sih-logo-group">
            <div className="sih-emblem-glow" />
            <div>
              <div className="sih-tagline">SMART INDIA HACKATHON — PROBLEM STATEMENT ID: 26101</div>
              <h2>MoSPI iGOT Karmayogi Capacity Building & AI Quiz Generator Master Suite</h2>
              <p className="sih-subtext">
                Ministry of Statistics and Programme Implementation (Data Informatics & Innovation Division - DIID)
              </p>
            </div>
          </div>

          <div className="sih-actions-group">
            <button onClick={handlePrepareIntegration} className="btn-sih-sync">
              <Server size={15} />
              <span>Prepare iGOT Integration</span>
            </button>
          </div>
        </div>

        {/* SIH Master Navigation Subtabs */}
        <div className="sih-nav-tabs">
          <button
            onClick={() => setActiveTab('heatmap')}
            className={`sih-nav-btn ${activeTab === 'heatmap' ? 'active' : ''}`}
          >
            <Database size={15} />
            <span>Ministry Competency Heatmap</span>
          </button>
          <button onClick={() => setActiveTab('admin')} className={`sih-nav-btn ${activeTab === 'admin' ? 'active' : ''}`}>
            <ShieldCheck size={15} /><span>Administrator Workspace</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`sih-nav-btn ${activeTab === 'profile' ? 'active' : ''}`}
          >
            <Users size={15} />
            <span>Official Skill-Gap & iGOT Pathways</span>
          </button>

          <button
            onClick={() => setActiveTab('nlp_quiz')}
            className={`sih-nav-btn ${activeTab === 'nlp_quiz' ? 'active' : ''}`}
          >
            <Brain size={15} />
            <span>AI Document NLP MCQ Generator</span>
          </button>

          <button
            onClick={() => setActiveTab('igot_api')}
            className={`sih-nav-btn ${activeTab === 'igot_api' ? 'active' : ''}`}
          >
            <Globe size={15} />
            <span>iGOT Ecosystem API Telemetry</span>
          </button>
        </div>
      </div>

      {/* --- TAB 1: MINISTRY COMPETENCY HEATMAP & CADRE ANALYTICS --- */}
      {activeTab === 'heatmap' && (
        <div className="sih-panel-view fade-in">
          <div className="sih-section-header">
            <h3>MoSPI Cadres & Division-Wide Competency Shortage Heatmap</h3>
            <p>Demo analytics model for mapping capacity gaps across ISS, SSS, FOD, SDRD, DPD, and DIID cadres.</p>
          </div>

          {/* Cadre Cards Grid */}
          <div className="sih-cadres-grid">
            {cadres.map(c => (
              <div key={c.cadre} className="sih-cadre-card">
                <div className="cadre-top">
                  <span className="cadre-badge">{c.cadre}</span>
                  <span className="cadre-name">{c.name}</span>
                </div>
                <p className="cadre-desc">{c.description}</p>

                <div className="cadre-metrics-row">
                  <div className="metric-box">
                    <span className="m-lbl">Demo officials</span>
                    <span className="m-val">1,240</span>
                  </div>
                  <div className="metric-box">
                    <span className="m-lbl">Illustrative AI/GIS gap</span>
                    <span className="m-val-red">38% Shortage</span>
                  </div>
                  <div className="metric-box">
                    <span className="m-lbl">Illustrative completion</span>
                    <span className="m-val-cyan">87%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Ministry Critical Skill Gaps Alert Box */}
          <div className="sih-alert-banner">
            <Sparkles className="icon-cyan" size={20} />
            <div>
              <h4>Prototype priority example - validate with authorised MoSPI data</h4>
              <p>
                82% of SSS Officers in Field Operations Division (FOD) require immediate upskilling in <strong>Automated Outlier Detection & CAPI Mobile Validation</strong>. 
                Recommended deployable pathway: <em>iGOT Course #igot-mospi-403</em>.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 2: OFFICIAL SKILL-GAP & IGOT PATHWAY RECOMMENDER --- */}
      {activeTab === 'profile' && (
        <div className="sih-panel-view fade-in">
          <div className="sih-profile-layout">
            {/* Left: Officials List */}
            <div className="officials-selector-panel">
              <h4>MoSPI Personnel Directory</h4>
              <div className="cadre-filter-chips">
                {['ALL', ...cadres.map(cadre => cadre.cadre)].map(f => (
                  <button
                    key={f}
                    onClick={() => {
                      setSelectedCadreFilter(f);
                      const nextOfficial = f === 'ALL' ? officials[0] : officials.find(official => official.cadre === f);
                      if (nextOfficial) setSelectedOfficial(nextOfficial);
                    }}
                    className={`filter-chip ${selectedCadreFilter === f ? 'active' : ''}`}
                  >
                    {f}
                  </button>
                ))}
              </div>

              <div className="officials-list">
                {filteredOfficials.map(off => (
                  <div
                    key={off.id}
                    onClick={() => setSelectedOfficial(off)}
                    className={`official-list-card ${selectedOfficial.id === off.id ? 'active' : ''}`}
                  >
                    <div className="off-name">{off.name}</div>
                    <div className="off-sub">{off.designation} • {off.postedDivision}</div>
                    <div className="off-readiness">
                      <span>Readiness:</span>
                      <span className="val-cyan">{off.overallReadinessIndexPct}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Selected Official Competency Radar & Pathways */}
            <div className="official-detail-panel flex-1">
              <div className="detail-header-card">
                <div>
                  <h3>{selectedOfficial.name}</h3>
                  <span className="sub-tag">{selectedOfficial.designation} ({selectedOfficial.cadre} Cadre) — {selectedOfficial.postedDivision}</span>
                </div>
                <div className="readiness-gauge-box">
                  <span className="gauge-lbl">Ministry Readiness Index</span>
                  <span className="gauge-val">{selectedOfficial.overallReadinessIndexPct}%</span>
                </div>
              </div>

              {/* Competencies Gap Bars */}
              <div className="competencies-radar-box">
                <h4>Individual Competency Gap Assessment</h4>
                <div className="comp-bars-list">
                  {selectedOfficial.competencies.map(comp => (
                    <div key={comp.id} className="comp-bar-item">
                      <div className="comp-bar-top">
                        <span className="comp-name">{comp.name}</span>
                        <span className="blooms-badge">Bloom's Target: {comp.bloomsLevelTarget}</span>
                      </div>
                      <p className="comp-desc">{comp.description}</p>
                      <div className="bar-track-wrapper">
                        <div className="track-bar">
                          <div className="fill cyan" style={{ width: `${comp.currentScorePct}%` }} />
                        </div>
                        <span className="bar-score">{comp.currentScorePct}% / {comp.requiredTargetScorePct}% (Gap: {comp.gapPct}%)</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Aligned iGOT Karmayogi Course Pathways */}
              <div className="igot-recommended-section">
                <h4>Recommended iGOT Karmayogi Learning Pathway</h4>
                <div className="courses-horizontal-grid">
                  {recommendedCourses.map(crs => (
                    <div key={crs.courseId} className="igot-card">
                      <div className="igot-top">
                        <Award size={18} className="icon-purple" />
                        <span className="provider-tag">{crs.provider}</span>
                      </div>
                      <h5>{crs.title}</h5>
                      <div className="igot-meta">
                        <span>{crs.durationHours} Hours • {crs.modulesCount} Modules</span>
                        <span className="blooms-tag">Focus: {crs.bloomsFocus}</span>
                      </div>
                      <div className="igot-footer">
                        <span className="completion-rate">Pass Rate: <strong>{crs.completionRatePct}%</strong></span>
                        <button onClick={handlePrepareIntegration} className="btn-enroll-igot">Prepare enrolment request</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 3: AI DOCUMENT NLP MCQ / QUIZ GENERATOR --- */}
      {activeTab === 'nlp_quiz' && (
        <div className="sih-panel-view fade-in">
          <div className="sih-section-header">
            <h3>AI-Powered Document NLP MCQ & Assessment Generator</h3>
            <p>Paste material or load TXT, MD, CSV, or JSON to generate traceable, Bloom's-taxonomy-classified draft questions. PDF/DOCX support is a planned secure-service feature.</p>
          </div>

          <div className="nlp-upload-section">
            <div className="nlp-box-header">
              <Upload size={18} className="icon-cyan" />
              <span>Input Learning Material (Official Statistics Course Module / Survey Manual)</span>
            </div>
            <textarea
              className="nlp-textarea"
              rows={4}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste course text or document content..."
            />
            <div className="nlp-file-row">
              <label className="btn-file-input">
                <Upload size={15} />
                <span>Load text-based file</span>
                <input type="file" accept=".txt,.md,.csv,.json,text/plain,text/markdown,text/csv,application/json" onChange={handleFileInput} />
              </label>
              <span className="input-status">{loadedFileName ? `Loaded: ${loadedFileName}` : inputStatus}</span>
            </div>
            <div className="nlp-action-bar">
              <button onClick={handleGenerateNLPQuizzes} className="btn-nlp-generate">
                <Zap size={16} />
                <span>Parse Document & Generate Bloom's Taxonomy MCQs</span>
              </button>
            </div>
          </div>

          {/* Generated MCQs Display */}
          <div className="generated-mcqs-container">
            <div className="mcq-list-header">
              <h4>Generated Assessment Items ({generatedQuizzes.length} Questions)</h4>
              <span className="mcq-sub">Classified by Bloom's Taxonomy & Distractor Fallacy Logic</span>
            </div>

            <div className="mcqs-grid">
              {generatedQuizzes.map((q, idx) => {
                const selectedIdx = selectedAnswers[q.id];
                const isCorrect = selectedIdx !== undefined && q.options[selectedIdx]?.isCorrect;

                return (
                  <div key={q.id} className="sih-mcq-card">
                    <div className="mcq-card-top">
                      <span className="q-number">Q{idx + 1}.</span>
                      <span className="blooms-pill">{q.bloomsLevel}</span>
                      <span className="domain-pill">{q.domainCategory}</span>
                    </div>

                    <div className="q-text">{q.questionText}</div>

                    <div className="options-stack">
                      {q.options.map((opt, oIdx) => {
                        const isSelected = selectedIdx === oIdx;
                        let btnStyle = 'option-row';
                        if (showQuizResults) {
                          if (opt.isCorrect) btnStyle += ' correct';
                          else if (isSelected && !opt.isCorrect) btnStyle += ' wrong';
                        } else if (isSelected) {
                          btnStyle += ' selected';
                        }

                        return (
                          <button
                            key={oIdx}
                            onClick={() => handleSelectOption(q.id, oIdx)}
                            className={btnStyle}
                          >
                            <span className="opt-lbl">{opt.label}.</span>
                            <span className="opt-txt">{opt.text}</span>
                          </button>
                        );
                      })}
                    </div>

                    {showQuizResults && (
                      <div className="explanation-box">
                        <div className="exp-head">
                          <CheckCircle size={15} className={isCorrect ? 'icon-emerald' : 'icon-red'} />
                          <span>{isCorrect ? 'Correct Answer' : 'Incorrect Choice'}</span>
                        </div>
                        <p>{q.explanation}</p>
                        <div className="distractor-info">
                          <span>Distractor Logic: <strong>{q.distractorFallacyType}</strong></span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="quiz-bottom-actions">
              <button onClick={() => setShowQuizResults(true)} className="btn-verify-answers">
                Verify Answers & View Explanations
              </button>
              <button onClick={handleGenerateNLPQuizzes} className="btn-regen-quizzes">
                <RefreshCw size={14} />
                <span>Regenerate MCQs</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 4: IGOT ECOSYSTEM API TELEMETRY & SYNC --- */}
      {activeTab === 'igot_api' && (
        <div className="sih-panel-view fade-in">
          <div className="sih-section-header">
            <h3>iGOT Karmayogi Ecosystem Integration & API Telemetry</h3>
            <p>Integration-readiness view. It shows the data contract the backend will need; it does not contact iGOT or claim a live connection.</p>
          </div>

          <div className="api-telemetry-grid">
            <div className="telemetry-card">
              <div className="tel-head">
                <Server size={18} className="icon-emerald" />
                <span>iGOT OAuth 2.0 Auth Server</span>
              </div>
              <div className="tel-status">PENDING AUTHORISATION</div>
              <div className="tel-endpoint">Await approved OAuth/SSO specification from iGOT</div>
            </div>

            <div className="telemetry-card">
              <div className="tel-head">
                <Layers size={18} className="icon-cyan" />
                <span>Competency Registry Schema</span>
              </div>
              <div className="tel-status">LOCAL DEMO SCHEMA</div>
              <div className="tel-endpoint">Map authorised competency records to the approved iGOT contract</div>
            </div>

            <div className="telemetry-card">
              <div className="tel-head">
                <FileText size={18} className="icon-purple" />
                <span>Course Telemetry Pipeline</span>
              </div>
              <div className="tel-status">NO LIVE TELEMETRY</div>
              <div className="tel-endpoint">Store only authorised progress events with consent and audit logging</div>
            </div>
          </div>
          <p className="integration-status">{integrationStatus}</p>

          {/* Raw JSON Schema Inspector */}
          <div className="schema-inspector-box">
            <div className="schema-header">
              <FileText size={16} className="icon-cyan" />
              <span>iGOT Karmayogi API Payload Schema (MoSPI DIID Endpoint)</span>
            </div>
            <pre className="json-schema-code">
{`{
  "system": "MoSPI DIID Capacity Building Platform",
  "problemStatementId": "26101",
  "ministry": "Ministry of Statistics and Programme Implementation",
  "cadreCoverage": ["ISS", "SSS", "FOD", "SDRD", "DPD", "DIID"],
  "integrationReadiness": {
    "requiredAuth": "Approved OAuth 2.0 / SSO specification",
    "competencyMapping": "Authorised MoSPI competency matrix",
    "questionGeneration": "Local rule-based prototype; AI service pending approval",
    "dataHandling": "Consent, role controls, encryption, and audit logs required"
  }
}`}
            </pre>
          </div>
        </div>
      )}

      {activeTab === 'admin' && (
        <div className="sih-panel-view fade-in admin-workspace">
          <div className="sih-section-header"><h3>Administrator Workspace</h3><p>A guided local workflow: source document → reviewable questions → approval. Nothing is sent to iGOT from this screen.</p></div>
          {!adminToken ? <div className="admin-card admin-login"><LockKeyhole className="icon-cyan" size={22} /><h4>Local administrator sign-in</h4><input value={adminEmail} onChange={e => setAdminEmail(e.target.value)} aria-label="Administrator email" /><input value={adminPassword} onChange={e => setAdminPassword(e.target.value)} type="password" placeholder="Password" aria-label="Administrator password" /><button onClick={handleAdminLogin} className="btn-nlp-generate">Sign in</button><p className="input-status">{adminStatus}</p></div> : <>
            <div className="admin-status"><ShieldCheck size={18} className="icon-emerald" />{adminStatus}</div>
            <div className="admin-grid">
              <section className="admin-card"><h4>1. Add learning material</h4><p>PDF, DOCX, TXT, MD, CSV, and JSON are supported by the local service.</p><input type="file" accept=".pdf,.docx,.txt,.md,.csv,.json" onChange={e => setAdminFile(e.target.files?.[0] || null)} /><button onClick={handleAdminUpload} className="btn-nlp-generate">Extract document text</button></section>
              <section className="admin-card"><h4>2. Review extracted material</h4><textarea value={adminText} onChange={e => setAdminText(e.target.value)} rows={8} placeholder="Extracted or pasted learning material appears here..." /><button disabled={adminText.trim().length < 20} onClick={handleAdminGenerate} className="btn-nlp-generate">Create assessment draft</button></section>
            </div>
            <section className="admin-card"><div className="admin-list-header"><h4>3. Review and publish drafts</h4><button onClick={loadAssessments} className="btn-regen-quizzes"><RefreshCw size={14} />Refresh list</button></div>{storedAssessments.length === 0 ? <p>Press “Refresh list” to load existing assessment drafts.</p> : storedAssessments.map(item => <div className="assessment-review" key={item.id}><div><strong>Assessment #{item.id}</strong><span className={`review-status ${item.status}`}>{item.status}</span><p>{item.questions.length} questions · {new Date(item.created_at).toLocaleString()}</p></div><div className="review-actions"><button onClick={() => handleReview(item.id, 'draft')} className="btn-regen-quizzes">Keep as draft</button><button onClick={() => handleReview(item.id, 'approved')} className="btn-verify-answers">Approve for use</button></div></div>)}</section>
          </>}
        </div>
      )}
    </div>
  );
};
