export type MoSPICadre = 'ISS' | 'SSS' | 'FOD' | 'SDRD' | 'DPD' | 'DIID';

export type BloomsLevel = 'Remembering' | 'Understanding' | 'Applying' | 'Analyzing' | 'Evaluating';

export interface CompetencyDimension {
  id: string;
  name: string;
  category: 'Domain Statistics' | 'Technical & Data Science' | 'Behavioral & Governance';
  description: string;
  currentScorePct: number;
  requiredTargetScorePct: number;
  gapPct: number;
  bloomsLevelTarget: BloomsLevel;
}

export interface MoSPIOfficialProfile {
  id: string;
  name: string;
  designation: string;
  cadre: MoSPICadre;
  postedDivision: string;
  yearsOfService: number;
  competencies: CompetencyDimension[];
  recommendedPathwayId: string;
  overallReadinessIndexPct: number;
}

export interface IGOTCourseSchema {
  courseId: string;
  title: string;
  provider: 'MoSPI NSSTA' | 'iGOT Karmayogi National Portal' | 'DIID Advanced Informatics';
  cadreTarget: MoSPICadre[];
  competencyDomain: string;
  durationHours: number;
  modulesCount: number;
  bloomsFocus: BloomsLevel;
  enrolledOfficialsCount: number;
  completionRatePct: number;
}

export interface AdvancedGeneratedMCQ {
  id: string;
  questionText: string;
  options: { label: string; text: string; isCorrect: boolean }[];
  explanation: string;
  bloomsLevel: BloomsLevel;
  domainCategory: string;
  distractorFallacyType: string;
  difficultyRating: number; // 1 to 5
}

interface QuestionTemplate {
  keywords: string[];
  concept: string;
  correctAnswer: string;
  explanation: string;
  bloomsLevel: BloomsLevel;
  domainCategory: string;
}

export class MoSPICompetencyFramework {
  static getCadresList(): { cadre: MoSPICadre; name: string; description: string }[] {
    return [
      { cadre: 'ISS', name: 'Indian Statistical Service', description: 'Senior statistical policy makers, survey designers, and national accounts architects.' },
      { cadre: 'SSS', name: 'Subordinate Statistical Service', description: 'Core statistical officers executing field data verification, index compilation, and processing.' },
      { cadre: 'FOD', name: 'Field Operations Division', description: 'Primary field survey enumerators and regional data collection supervisors.' },
      { cadre: 'SDRD', name: 'Survey Design & Research Division', description: 'Sampling design specialists, questionnaire architects, and methodological researchers.' },
      { cadre: 'DPD', name: 'Data Processing Division', description: 'Large-scale electronic survey data validation, tabulation, and database management.' },
      { cadre: 'DIID', name: 'Data Informatics & Innovation Division', description: 'AI/ML adoption, GIS spatial analytics, cloud infrastructure, and open data APIs.' }
    ];
  }

  static getSampleMoSPIOfficials(): MoSPIOfficialProfile[] {
    return [
      {
        id: 'off-101',
        name: 'Dr. Rajesh Sharma, ISS',
        designation: 'Deputy Director General',
        cadre: 'ISS',
        postedDivision: 'SDRD Kolkata',
        yearsOfService: 16,
        overallReadinessIndexPct: 78,
        recommendedPathwayId: 'path-iss-ai-gis',
        competencies: [
          { id: 'c1', name: 'National Accounts & GDP Computation', category: 'Domain Statistics', description: 'SNA 2008 standards & Gross Value Added estimation', currentScorePct: 92, requiredTargetScorePct: 95, gapPct: 3, bloomsLevelTarget: 'Evaluating' },
          { id: 'c2', name: 'AI & ML for Survey Imputation', category: 'Technical & Data Science', description: 'Random Forests & Neural Nets for missing survey data imputation', currentScorePct: 45, requiredTargetScorePct: 85, gapPct: 40, bloomsLevelTarget: 'Applying' },
          { id: 'c3', name: 'GIS Spatial Remote Sensing', category: 'Technical & Data Science', description: 'Integrating QGIS & satellite imagery into agricultural crop yield estimation', currentScorePct: 38, requiredTargetScorePct: 80, gapPct: 42, bloomsLevelTarget: 'Applying' },
          { id: 'c4', name: 'Big Data Cloud Pipelines', category: 'Technical & Data Science', description: 'Spark/Hadoop infrastructure for real-time Consumer Price Index ingestion', currentScorePct: 50, requiredTargetScorePct: 75, gapPct: 25, bloomsLevelTarget: 'Understanding' }
        ]
      },
      {
        id: 'off-102',
        name: 'Priya Sundaram, SSS',
        designation: 'Senior Statistical Officer',
        cadre: 'SSS',
        postedDivision: 'FOD Regional Office Chennai',
        yearsOfService: 8,
        overallReadinessIndexPct: 64,
        recommendedPathwayId: 'path-sss-field-digital',
        competencies: [
          { id: 'c5', name: 'CAPI Digital Data Collection', category: 'Domain Statistics', description: 'Computer-Assisted Personal Interviewing handheld survey validation', currentScorePct: 80, requiredTargetScorePct: 90, gapPct: 10, bloomsLevelTarget: 'Applying' },
          { id: 'c6', name: 'Automated Anomaly & Outlier Detection', category: 'Technical & Data Science', description: 'Python Isolation Forests for flagging falsified or erroneous survey rows', currentScorePct: 30, requiredTargetScorePct: 75, gapPct: 45, bloomsLevelTarget: 'Applying' },
          { id: 'c7', name: 'Industrial Statistics (ASI / IIP)', category: 'Domain Statistics', description: 'Annual Survey of Industries & Index of Industrial Production compilation', currentScorePct: 75, requiredTargetScorePct: 85, gapPct: 10, bloomsLevelTarget: 'Analyzing' }
        ]
      }
    ];
  }

  static getIGOTCourseCatalog(): IGOTCourseSchema[] {
    return [
      {
        courseId: 'igot-mospi-401',
        title: 'Advanced AI & Machine Learning for Official Survey Imputation',
        provider: 'DIID Advanced Informatics',
        cadreTarget: ['ISS', 'SDRD', 'DPD', 'DIID'],
        competencyDomain: 'AI & ML for Survey Imputation',
        durationHours: 36,
        modulesCount: 8,
        bloomsFocus: 'Applying',
        enrolledOfficialsCount: 1420,
        completionRatePct: 84
      },
      {
        courseId: 'igot-mospi-402',
        title: 'GIS Remote Sensing & Spatial Sampling for National Surveys',
        provider: 'MoSPI NSSTA',
        cadreTarget: ['ISS', 'SSS', 'FOD', 'SDRD'],
        competencyDomain: 'GIS Spatial Remote Sensing',
        durationHours: 24,
        modulesCount: 6,
        bloomsFocus: 'Analyzing',
        enrolledOfficialsCount: 2150,
        completionRatePct: 91
      },
      {
        courseId: 'igot-mospi-403',
        title: 'CAPI Mobile Survey Validation & Real-Time Anomaly Flagging',
        provider: 'iGOT Karmayogi National Portal',
        cadreTarget: ['SSS', 'FOD', 'DPD'],
        competencyDomain: 'Automated Anomaly & Outlier Detection',
        durationHours: 18,
        modulesCount: 5,
        bloomsFocus: 'Applying',
        enrolledOfficialsCount: 4800,
        completionRatePct: 89
      }
    ];
  }

  static getRecommendedCoursesForOfficial(official: MoSPIOfficialProfile): IGOTCourseSchema[] {
    const largestGaps = [...official.competencies].sort((a, b) => b.gapPct - a.gapPct).slice(0, 3);
    return this.getIGOTCourseCatalog()
      .map(course => ({
        course,
        score: (course.cadreTarget.includes(official.cadre) ? 100 : 0)
          + largestGaps.reduce((sum, gap) => sum + (course.competencyDomain === gap.name ? gap.gapPct : 0), 0)
      }))
      .filter(({ score }) => score > 0)
      .sort((a, b) => b.score - a.score)
      .map(({ course }) => course);
  }

  static parseDocumentAndGenerateNLPQuizzes(textMaterial: string, numQuestions: number = 4): AdvancedGeneratedMCQ[] {
    const normalizedText = textMaterial.toLowerCase();
    const templates: QuestionTemplate[] = [
      { keywords: ['capi', 'computer-assisted personal interviewing'], concept: 'CAPI', correctAnswer: 'Computer-Assisted Personal Interviewing', explanation: 'The submitted material identifies CAPI as the digital field-data collection approach.', bloomsLevel: 'Understanding', domainCategory: 'Data Collection' },
      { keywords: ['isolation forest', 'outlier', 'anomaly'], concept: 'anomaly detection', correctAnswer: 'Isolation Forest-based anomaly detection', explanation: 'The submitted material links anomaly detection with identifying unusual or suspicious data records.', bloomsLevel: 'Applying', domainCategory: 'Data Informatics & Anomaly Detection' },
      { keywords: ['non-response', 'nonresponse'], concept: 'non-response bias', correctAnswer: 'Bias caused when selected units do not provide responses', explanation: 'The material explicitly raises non-response as a survey-quality risk requiring adjustment or investigation.', bloomsLevel: 'Analyzing', domainCategory: 'Survey Methodology' },
      { keywords: ['gva', 'gross value added'], concept: 'Gross Value Added', correctAnswer: 'The value generated by production before product taxes and subsidies', explanation: 'GVA is a national-accounts measure referenced in the submitted learning material.', bloomsLevel: 'Understanding', domainCategory: 'National Accounts' },
      { keywords: ['gis', 'satellite', 'remote sensing', 'ndvi'], concept: 'GIS and remote sensing', correctAnswer: 'Spatial data used to analyse locations, patterns, and conditions', explanation: 'The material uses GIS or remote sensing as a source of geographically referenced evidence.', bloomsLevel: 'Applying', domainCategory: 'GIS & Spatial Analytics' },
      { keywords: ['imputation', 'missing data'], concept: 'imputation', correctAnswer: 'Estimating a plausible value for missing data', explanation: 'The material associates imputation with managing incomplete observations without simply discarding them.', bloomsLevel: 'Applying', domainCategory: 'Survey Methodology & AI Imputation' },
      { keywords: ['cloud', 'pipeline', 'database'], concept: 'data pipeline', correctAnswer: 'A managed flow for collecting, processing, and storing data', explanation: 'The submitted material describes a data-processing workflow rather than an isolated data file.', bloomsLevel: 'Understanding', domainCategory: 'Cloud Data Informatics' }
    ];

    const matched = templates.filter(template => template.keywords.some(keyword => normalizedText.includes(keyword)));
    const selected = (matched.length > 0 ? matched : templates).slice(0, numQuestions);
    const distractors = ['A manual paper-only process', 'Deleting records without review', 'An unrelated demographic indicator'];

    return selected.map((template, index) => ({
      id: `generated-${index + 1}`,
      questionText: `According to the submitted material, which option best describes ${template.concept}?`,
      options: [
        { label: 'A', text: template.correctAnswer, isCorrect: true },
        ...distractors.map((text, distractorIndex) => ({ label: String.fromCharCode(66 + distractorIndex), text, isCorrect: false }))
      ],
      explanation: template.explanation,
      bloomsLevel: template.bloomsLevel,
      domainCategory: template.domainCategory,
      distractorFallacyType: 'Unrelated-process and over-simplification distractors',
      difficultyRating: template.bloomsLevel === 'Analyzing' ? 4 : 3
    }));
  }
}
